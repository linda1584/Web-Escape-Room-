
$(document).ready(function(){
    $("#inizia1").click(vaiEnigma1);
})

function vaiEnigma1(){
    window.location.href = "enigma1.html";    
}
